package kr.ac.kau.sw.a2016125063.working

import android.app.ActivityManager
import android.app.IntentService
import android.content.Intent
import android.content.IntentFilter

import android.content.Context.ACTIVITY_SERVICE

/**
 * Created by Arduino on 2017-11-08.
 */

class Kotlin internal constructor() : IntentService("") {
    var threadIsTerminate = false //是否开启循环


    private val lastUnlockTimeSeconds: Long = 0 //最后解锁的时间
    private val lastUnlockPackageName = "" //最后解锁的程序包名

    private val lockState: Boolean = false

    private var activityManager: ActivityManager? = null
    var savePkgName: String? = null

    override fun onCreate() {
        super.onCreate()
        activityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager

        //注册广播
        val filter = IntentFilter()
        filter.addAction(Intent.ACTION_SCREEN_ON)
        filter.addAction(Intent.ACTION_SCREEN_OFF)
        filter.addAction(UNLOCK_ACTION)

    }

    override fun onHandleIntent(intent: Intent?) {

    }

    companion object {

        val UNLOCK_ACTION = "UNLOCK_ACTION"
        val LOCK_SERVICE_LASTTIME = "LOCK_SERVICE_LASTTIME"
        val LOCK_SERVICE_LASTAPP = "LOCK_SERVICE_LASTAPP"

        var isActionLock = false
    }
}
